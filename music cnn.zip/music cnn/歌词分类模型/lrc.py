import os
import json
import tensorflow as tf
from tensorflow.keras import layers, models
import pathlib
from tkinter import Tk, Button, Label, Entry, filedialog, messagebox, Checkbutton, BooleanVar, Scale, Frame, ttk, Radiobutton, Toplevel
import threading
from threading import Event
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from tensorflow.keras.layers import TextVectorization
import numpy as np
import sys

# 配置 GPU
gpus = tf.config.list_physical_devices("GPU")
if gpus:
    try:
        for gpu in gpus:
            tf.config.experimental.set_memory_growth(gpu, True)
        tf.config.set_visible_devices(gpus, "GPU")
        print("GPU 配置成功，内存增长已开启。")
    except RuntimeError as e:
        print(f"GPU配置失败，可能需要在程序启动时设置: {e}")
else:
    print("未检测到GPU，将使用CPU进行训练。")

# 获取系统文件系统编码
FILE_SYSTEM_ENCODING = sys.getfilesystemencoding()
print(f"检测到文件系统编码: {FILE_SYSTEM_ENCODING}")

# 创建主窗口
root = Tk()
root.title("文本分类模型训练")
root.geometry("700x860") # Increased height for new options

# 全局变量
data_dir = None
train_dir = None
val_dir = None
continue_training = False
model_to_continue = None
stop_training_event = Event()
dataset_split_method = BooleanVar(value=True)
loaded_metadata = None

# 默认值 (文本分类相关)
DEFAULT_BATCH_SIZE = 32
DEFAULT_MAX_TOKENS = 10000
DEFAULT_SEQUENCE_LENGTH = 256
DEFAULT_DATASET_ENCODING = "utf-8" # New default encoding

# 辅助函数：安全地设置路径
def set_path_safely(path_var_name, label_widget):
    selected_dir = filedialog.askdirectory(title=f"选择 {path_var_name} 文件夹")
    if selected_dir:
        try:
            # 尝试以文件系统编码解码路径，以检查潜在问题
            decoded_path_for_check = selected_dir.encode(FILE_SYSTEM_ENCODING, errors='strict').decode(FILE_SYSTEM_ENCODING)
            if decoded_path_for_check != selected_dir:
                messagebox.showwarning("路径警告", f"所选路径可能包含无法以当前系统编码 ({FILE_SYSTEM_ENCODING}) 完全表示的字符。请考虑使用英文字符路径。路径: {selected_dir}")

            p = pathlib.Path(selected_dir)
            if not p.exists():
                messagebox.showerror("错误", f"所选路径 '{selected_dir}' 不存在。")
                label_widget.config(text="路径无效", fg="red")
                return None
            if not p.is_dir():
                messagebox.showerror("错误", f"所选路径 '{selected_dir}' 不是一个有效的文件夹。")
                label_widget.config(text="路径无效", fg="red")
                return None

            # 尝试列出目录内容
            try:
                # This could still cause UnicodeDecodeError if directory names or filenames are problematic
                _ = os.listdir(selected_dir)
            except UnicodeDecodeError:
                messagebox.showerror("编码错误", f"所选文件夹路径或其内部文件/文件夹名称包含无法识别的字符。请将路径和文件名（尤其是中文部分）修改为纯英文字符。路径: {selected_dir}")
                label_widget.config(text="编码错误", fg="red")
                return None
            except Exception as e:
                messagebox.showwarning("路径访问警告", f"尝试访问文件夹内容时遇到意外错误: {e}\n这可能与权限或特殊文件名有关。")

            label_widget.config(text=f"{path_var_name} 路径: {p}", fg="black")
            return p
        except UnicodeEncodeError:
            messagebox.showerror("编码错误", f"所选路径 '{selected_dir}' 无法以当前系统文件系统编码 ({FILE_SYSTEM_ENCODING}) 进行编码。请确保路径只包含英文字符。")
            label_widget.config(text="编码错误", fg="red")
            return None
        except Exception as e:
            messagebox.showerror("错误", f"处理路径 '{selected_dir}' 时发生错误: {e}\n请确保路径和文件名只包含英文字符。")
            label_widget.config(text="加载失败", fg="red")
            return None
    else:
        messagebox.showwarning("警告", f"未选择 {path_var_name} 文件夹！")
        label_widget.config(text="未选择", fg="red")
        return None

# 选择数据集文件夹
def select_data_dir():
    global data_dir
    data_dir = set_path_safely("数据集", data_dir_label)

# 选择训练集文件夹
def select_train_dir():
    global train_dir
    train_dir = set_path_safely("训练集", train_dir_label)

# 选择验证集文件夹
def select_val_dir():
    global val_dir
    val_dir = set_path_safely("验证集", val_dir_label)

# 选择继续训练的模型文件
def select_model_to_continue():
    global model_to_continue, loaded_metadata
    selected_model_path = filedialog.askopenfilename(
        title="选择继续训练的模型文件",
        filetypes=[("Keras 文件", "*.keras")]
    )
    if selected_model_path:
        model_to_continue = selected_model_path
        continue_model_label.config(text=f"继续训练模型路径: {model_to_continue}", fg="black")

        model_directory = pathlib.Path(model_to_continue).parent
        metadata_path = model_directory / "metadata.json"

        if metadata_path.exists():
            try:
                with open(metadata_path, 'r', encoding='utf-8') as f:
                    loaded_metadata = json.load(f)
                print(f"已加载元数据: {metadata_path}")
            except json.JSONDecodeError as e:
                messagebox.showerror("错误", f"加载元数据文件失败: {e}\n请确保 'metadata.json' 文件未损坏且为有效的 JSON 格式。")
                loaded_metadata = None
            except Exception as e:
                messagebox.showerror("错误", f"读取元数据文件时发生未知错误: {e}")
                loaded_metadata = None

            if loaded_metadata:
                if not loaded_metadata.get("vocabulary"):
                    messagebox.showwarning("警告", "元数据文件中未找到词汇表 ('vocabulary' 键)。")
                if not loaded_metadata.get("class_names"):
                    messagebox.showwarning("警告", "元数据文件中未找到类别名称 ('class_names' 键)。")
            else:
                messagebox.showwarning("警告", "未能成功加载元数据（可能是空文件或内容错误）。")
        else:
            loaded_metadata = None
            messagebox.showwarning("警告", "继续训练模式下，未找到配套的元数据文件 (metadata.json)，继续训练可能导致不一致。")

    else:
        messagebox.showwarning("警告", "未选择继续训练的模型文件！")
        model_to_continue = None
        loaded_metadata = None
        continue_model_label.config(text="未选择", fg="red")

# 停止训练
def stop_training_callback():
    stop_training_event.set()
    stop_button.config(state="disabled")
    messagebox.showinfo("提示", "训练将在当前轮次完成后停止...")

# 更新训练状态
def update_training_status(epoch, logs):
    current_epoch_label.config(text=f"当前轮数: {epoch + 1}")
    train_loss_label.config(text=f"训练损失: {logs.get('loss', 0.0):.4f}")
    train_acc_label.config(text=f"训练准确率: {logs.get('accuracy', 0.0):.4f}")
    val_loss_label.config(text=f"验证损失: {logs.get('val_loss', 0.0):.4f}")
    val_acc_label.config(text=f"验证准确率: {logs.get('val_accuracy', 0.0):.4f}")
    root.update_idletasks()

# 自定义回调以支持停止训练
class StopTrainingCallback(tf.keras.callbacks.Callback):
    def on_epoch_end(self, epoch, logs=None):
        update_training_status(epoch, logs)
        if stop_training_event.is_set():
            print("训练停止")
            self.model.stop_training = True
            messagebox.showinfo("训练状态", "训练已由用户停止。")

# 创建文本向量化层
def create_text_vectorization_layer(max_tokens, sequence_length, vocabulary=None):
    text_vectorization = TextVectorization(
        max_tokens=max_tokens,
        output_mode='int',
        output_sequence_length=sequence_length,
        standardize="lower_and_strip_punctuation"
    )
    if vocabulary:
        text_vectorization.set_vocabulary(vocabulary)
        print("TextVectorization层已设置预加载词汇表。")
    return text_vectorization

# 创建模型
def create_model(num_classes, vocab_size, embedding_dim=128):
    model = models.Sequential([
        layers.Embedding(input_dim=vocab_size, output_dim=embedding_dim),
        layers.GlobalAveragePooling1D(),
        layers.Dropout(0.5),
        layers.Dense(64, activation='relu'),
        layers.Dropout(0.5),
        layers.Dense(num_classes, activation='softmax')
    ])
    return model

# 绘制训练历史图像
def plot_training_history(history):
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))
    ax1.plot(history.history['loss'], label='Training Loss')
    ax1.plot(history.history['val_loss'], label='Validation Loss')
    ax1.set_title('Training and Validation Loss')
    ax1.set_xlabel('Epoch')
    ax1.set_ylabel('Loss')
    ax1.legend()
    ax2.plot(history.history['accuracy'], label='Training Accuracy')
    ax2.plot(history.history['val_accuracy'], label='Validation Accuracy')
    ax2.set_title('Training and Validation Accuracy')
    ax2.set_xlabel('Epoch')
    ax2.set_ylabel('Accuracy')
    ax2.legend()
    plt.tight_layout()
    return fig

# 在弹窗中显示训练历史图像
def show_training_history(history):
    popup = Toplevel()
    popup.title("训练历史")
    popup.geometry("800x500")
    fig = plot_training_history(history)
    canvas = FigureCanvasTkAgg(fig, master=popup)
    canvas.draw()
    canvas.get_tk_widget().pack(fill="both", expand=True)
    close_button = Button(popup, text="关闭", command=popup.destroy)
    close_button.pack(pady=10)
    plt.close(fig)

# --- NEW: Custom data loading function ---
def load_text_dataset_from_directory_custom(directory, encoding, batch_size, label_mode='categorical', validation_split=0.0, subset=None, seed=123):
    text_data = []
    labels = []
    class_names = []

    if isinstance(directory, pathlib.Path):
        directory = str(directory)

    # Walk through the directory to find text files and class names
    for class_index, class_name in enumerate(sorted(os.listdir(directory))):
        class_path = os.path.join(directory, class_name)
        if os.path.isdir(class_path):
            class_names.append(class_name)
            for filename in os.listdir(class_path):
                if filename.endswith(".txt") or filename.endswith(".lrc"): # Assuming text files
                    file_path = os.path.join(class_path, filename)
                    try:
                        with open(file_path, 'r', encoding=encoding) as f:
                            text_content = f.read()
                        text_data.append(text_content)
                        labels.append(class_index)
                    except UnicodeDecodeError:
                        messagebox.showerror("编码错误", f"无法使用 '{encoding}' 编码读取文件: {file_path}\n请检查您的文件编码并确保选择正确的编码类型。")
                        raise
                    except Exception as e:
                        messagebox.showerror("文件读取错误", f"读取文件时发生错误: {file_path}\n错误: {e}")
                        raise

    if not class_names:
        raise ValueError(f"在 '{directory}' 中未找到任何子文件夹作为类别。请确保您的数据集结构为: root_dir/class_a/a.txt, root_dir/class_b/b.txt")

    # Convert lists to numpy arrays for slicing
    text_data = np.array(text_data)
    labels = np.array(labels)

    # Shuffle data before splitting
    if seed is not None:
        np.random.seed(seed)
    shuffled_indices = np.random.permutation(len(text_data))
    text_data = text_data[shuffled_indices]
    labels = labels[shuffled_indices]

    train_size = int(len(text_data) * (1 - validation_split))

    final_text_data = []
    final_labels = []

    if subset == "training":
        final_text_data = text_data[:train_size]
        final_labels = labels[:train_size]
    elif subset == "validation":
        final_text_data = text_data[train_size:]
        final_labels = labels[train_size:]
    elif subset is None: # Load all if no subset specified for manual upload
        final_text_data = text_data
        final_labels = labels

    if len(final_text_data) == 0:
        raise ValueError(f"在 '{directory}' 找不到数据，请检查数据集是否正确!")


    # Convert labels to categorical (one-hot) if needed
    if label_mode == 'categorical':
        final_labels = tf.keras.utils.to_categorical(final_labels, num_classes=len(class_names))

    # Create tf.data.Dataset
    dataset = tf.data.Dataset.from_tensor_slices((final_text_data, final_labels))
    dataset = dataset.batch(batch_size) # Batch the dataset

    # Attach class_names
    dataset.class_names = class_names
    return dataset

# --- END NEW: Custom data loading function ---


# 训练任务
def train_task():
    global data_dir, train_dir, val_dir, continue_training, model_to_continue, loaded_metadata

    disable_all_buttons()

    # Get dataset encoding from UI
    dataset_encoding = dataset_encoding_entry.get().strip().lower()
    if not dataset_encoding:
        messagebox.showerror("错误", "请指定数据集文本文件的编码类型（例如: utf-8, gbk）")
        enable_all_buttons()
        return

    try:
        # Test if the encoding is valid
        "test_string".encode(dataset_encoding)
    except LookupError:
        messagebox.showerror("编码错误", f"无效的编码类型: '{dataset_encoding}'。请使用Python支持的编码名称，例如 'utf-8', 'gbk', 'latin-1'。")
        enable_all_buttons()
        return


    try:
        if dataset_split_method.get():
            if not data_dir or not data_dir.exists() or not data_dir.is_dir():
                messagebox.showerror("错误", "数据集文件夹不存在或未选择！")
                enable_all_buttons()
                return
            base_dir_for_tf = data_dir
        else:
            if not train_dir or not train_dir.exists() or not train_dir.is_dir():
                messagebox.showerror("错误", "训练集文件夹不存在或未选择！")
                enable_all_buttons()
                return
            if not val_dir or not val_dir.exists() or not val_dir.is_dir():
                messagebox.showerror("错误", "验证集文件夹不存在或未选择！")
                enable_all_buttons()
                return
            base_dir_train_for_tf = train_dir
            base_dir_val_for_tf = val_dir
    except Exception as e:
        messagebox.showerror("路径验证错误", f"验证文件路径时发生错误: {e}\n请确保路径只包含英文字符。")
        enable_all_buttons()
        return

    continue_training = continue_training_var.get()
    if continue_training:
        if not model_to_continue or not os.path.exists(model_to_continue):
            messagebox.showerror("错误", "继续训练的模型文件不存在或未选择！")
            enable_all_buttons()
            return
        if loaded_metadata is None or not loaded_metadata.get("vocabulary") or not loaded_metadata.get("class_names"):
            messagebox.showwarning("警告", "继续训练模式下，未成功加载模型配套的元数据。请确保选择的模型文件夹中包含 'metadata.json' 文件且包含 'vocabulary' 和 'class_names' 键。训练将继续，但可能遇到问题。")

    batch_size = int(batch_size_entry.get() or DEFAULT_BATCH_SIZE)
    max_tokens = int(max_tokens_entry.get() or DEFAULT_MAX_TOKENS)
    sequence_length = int(sequence_length_entry.get() or DEFAULT_SEQUENCE_LENGTH)
    validation_split = float(validation_split_scale.get() / 100.0)
    learning_rate = float(learning_rate_entry.get() or 0.001)
    epochs = int(epochs_entry.get() or 10)

    try:
        # --- Using custom data loader ---
        if dataset_split_method.get():
            # For automatic split, load the whole dataset once and then split.
            # Or, simulate validation_split within load_text_dataset_from_directory_custom.
            # Simpler to load training and validation subsets separately as done by tf.keras.preprocessing.text_dataset_from_directory
            raw_train_ds = load_text_dataset_from_directory_custom(
                base_dir_for_tf,
                encoding=dataset_encoding,
                batch_size=batch_size,
                label_mode='categorical',
                validation_split=validation_split,
                subset="training",
                seed=123
            )
            raw_val_ds = load_text_dataset_from_directory_custom(
                base_dir_for_tf,
                encoding=dataset_encoding,
                batch_size=batch_size,
                label_mode='categorical',
                validation_split=validation_split,
                subset="validation",
                seed=123
            )
        else:
            raw_train_ds = load_text_dataset_from_directory_custom(
                base_dir_train_for_tf,
                encoding=dataset_encoding,
                batch_size=batch_size,
                label_mode='categorical',
                subset=None, # Load all for manual upload
                seed=123
            )
            raw_val_ds = load_text_dataset_from_directory_custom(
                base_dir_val_for_tf,
                encoding=dataset_encoding,
                batch_size=batch_size,
                label_mode='categorical',
                subset=None, # Load all for manual upload
                seed=123
            )
        # --- End custom data loader usage ---

    except Exception as e:
        messagebox.showerror("数据集加载错误", f"加载数据集时发生错误: {e}\n\n请确保：\n1. 数据集文件夹结构正确 (root_dir/class_name/file.txt)。\n2. 您选择的编码 '{dataset_encoding}' 与您文本文件的实际编码一致。\n3. 所有文件夹和文件名称只包含英文字符。")
        enable_all_buttons()
        return

    current_class_names = raw_train_ds.class_names
    num_classes = len(current_class_names)
    print(f"当前数据集类别: {current_class_names}")

    if continue_training and loaded_metadata and loaded_metadata.get("class_names"):
        loaded_class_names = loaded_metadata.get("class_names")
        if set(current_class_names) != set(loaded_class_names):
            messagebox.showwarning("警告", f"当前数据集类别 ({current_class_names}) 与加载模型的类别 ({loaded_class_names}) 内容不一致！这可能导致训练问题。")
        if len(current_class_names) != len(loaded_class_names):
            messagebox.showwarning("警告", f"当前数据集类别数量 ({len(current_class_names)}) 与加载模型的类别数量 ({len(loaded_class_names)}) 不一致！模型可能无法正确加载。")

    text_vectorization_vocab_to_use = None
    if continue_training and loaded_metadata:
        text_vectorization_vocab_to_use = loaded_metadata.get("vocabulary")

    text_vectorization_layer = create_text_vectorization_layer(
        max_tokens,
        sequence_length,
        vocabulary=text_vectorization_vocab_to_use
    )

    if text_vectorization_vocab_to_use is None or not continue_training:
        print("适应TextVectorization层词汇表...")
        # Adapt on the raw text data before batching/vectorizing
        # For custom loader, we need to extract raw text again from the dataset if not already
        all_text_data_for_adapt = raw_train_ds.map(lambda text, labels: text).unbatch()
        text_vectorization_layer.adapt(all_text_data_for_adapt)
        print("TextVectorization层词汇表适应完成。")
    else:
        print("使用预加载词汇表，跳过TextVectorization层适应。")

    def vectorize_text(text, label):
        text = tf.expand_dims(text, -1)
        return text_vectorization_layer(text), label

    # Map text vectorization to the buffered datasets
    train_ds = raw_train_ds.map(vectorize_text)
    val_ds = raw_val_ds.map(vectorize_text)


    AUTOTUNE = tf.data.AUTOTUNE
    train_ds = train_ds.cache().prefetch(buffer_size=AUTOTUNE)
    val_ds = val_ds.cache().prefetch(buffer_size=AUTOTUNE)

    model = None
    if continue_training:
        try:
            model = tf.keras.models.load_model(model_to_continue)
            print(f"成功加载模型: {model_to_continue}")
            if model.layers[-1].output_shape[-1] != num_classes:
                messagebox.showwarning("警告", f"加载模型的输出层神经元数量 ({model.layers[-1].output_shape[-1]}) 与当前数据集类别数量 ({num_classes}) 不匹配。这可能导致训练错误。")
        except Exception as e:
            messagebox.showerror("错误", f"加载模型失败: {e}\n请确保模型文件未损坏，且与当前 TensorFlow 版本兼容。")
            enable_all_buttons()
            return
    else:
        vocab_size = text_vectorization_layer.vocabulary_size()
        model = create_model(num_classes, vocab_size)

    model.summary()

    opt = tf.keras.optimizers.Adam(learning_rate=learning_rate)
    model.compile(
        optimizer=opt,
        loss='categorical_crossentropy',
        metrics=['accuracy']
    )

    stop_button.config(state="normal")
    start_button.config(state="disabled")

    callbacks = [
        StopTrainingCallback(),
    ]
    history = model.fit(
        train_ds,
        epochs=epochs,
        validation_data=val_ds,
        callbacks=callbacks
    )

    save_model = messagebox.askyesno("保存模型", "是否保存模型？")
    if save_model:
        folder_to_save = filedialog.askdirectory(title="选择保存模型和相关文件的文件夹")
        if folder_to_save:
            save_folder_path = pathlib.Path(folder_to_save)
            model_save_path = save_folder_path / "text_model.keras"
            try:
                model.save(str(model_save_path))

                metadata = {
                    "class_names": current_class_names,
                    "vocabulary": text_vectorization_layer.get_vocabulary()
                }
                metadata_path = save_folder_path / "metadata.json"
                with open(metadata_path, 'w', encoding='utf-8') as f: # Always save metadata as UTF-8
                    json.dump(metadata, f, ensure_ascii=False, indent=4)

                messagebox.showinfo("成功", f"模型和元数据已保存到: {folder_to_save}")
            except Exception as e:
                messagebox.showerror("保存失败", f"保存模型或相关文件时发生错误: {e}\n请确保选择的保存路径没有特殊字符且可写。")
        else:
            messagebox.showwarning("警告", "未选择保存模型的文件夹，模型将不被保存。")

    if history:
        show_training_history(history)
    else:
        messagebox.showinfo("信息", "没有训练历史可显示。")

    stop_training_event.clear()
    enable_all_buttons()
    messagebox.showinfo("完成", "训练完成！")

# 启用所有按钮
def enable_all_buttons():
    data_dir_button.config(state="normal")
    train_dir_button.config(state="normal")
    val_dir_button.config(state="normal")
    continue_model_button.config(state="normal")
    batch_size_entry.config(state="normal")
    max_tokens_entry.config(state="normal")
    sequence_length_entry.config(state="normal")
    validation_split_scale.config(state="normal")
    learning_rate_entry.config(state="normal")
    epochs_entry.config(state="normal")
    dataset_encoding_entry.config(state="normal") # Enable encoding entry
    dataset_split_method_auto.config(state="normal")
    dataset_split_method_manual.config(state="normal")
    start_button.config(state="normal")
    stop_button.config(state="disabled")
    toggle_dataset_selection()

# 禁用所有按钮 (用于训练期间)
def disable_all_buttons():
    data_dir_button.config(state="disabled")
    data_dir_label.config(fg="gray")
    train_dir_button.config(state="disabled")
    train_dir_label.config(fg="gray")
    val_dir_button.config(state="disabled")
    val_dir_label.config(fg="gray")
    continue_model_button.config(state="disabled")
    continue_model_label.config(fg="gray")
    batch_size_entry.config(state="disabled")
    max_tokens_entry.config(state="disabled")
    sequence_length_entry.config(state="disabled")
    validation_split_scale.config(state="disabled")
    learning_rate_entry.config(state="disabled")
    epochs_entry.config(state="disabled")
    dataset_encoding_entry.config(state="disabled") # Disable encoding entry
    dataset_split_method_auto.config(state="disabled")
    dataset_split_method_manual.config(state="disabled")
    start_button.config(state="disabled")
    stop_button.config(state="normal")

# 开始训练（启动多线程）
def start_training():
    stop_training_event.clear()
    training_thread = threading.Thread(target=train_task)
    training_thread.start()

# 动态禁用或启用文件夹选择按钮
def toggle_dataset_selection():
    if dataset_split_method.get():
        data_dir_button.config(state="normal")
        data_dir_label.config(fg="black" if data_dir else "red")
        train_dir_button.config(state="disabled")
        train_dir_label.config(fg="gray")
        val_dir_button.config(state="disabled")
        val_dir_label.config(fg="gray")
        validation_split_scale.config(state="normal")
    else:
        data_dir_button.config(state="disabled")
        data_dir_label.config(fg="gray")
        train_dir_button.config(state="normal")
        train_dir_label.config(fg="black" if train_dir else "red")
        val_dir_button.config(state="normal")
        val_dir_label.config(fg="black" if val_dir else "red")
        validation_split_scale.config(state="disabled")

# GUI 布局
frame = Frame(root)
frame.pack(padx=10, pady=10)

# 数据集划分方式选择
Label(frame, text="数据集划分方式:").grid(row=0, column=0, padx=10, pady=10)
dataset_split_method_auto = Radiobutton(frame, text="自动划分训练集和验证集", variable=dataset_split_method, value=True, command=toggle_dataset_selection)
dataset_split_method_auto.grid(row=0, column=1, padx=10, pady=10)
dataset_split_method_manual = Radiobutton(frame, text="手动上传训练集和验证集", variable=dataset_split_method, value=False, command=toggle_dataset_selection)
dataset_split_method_manual.grid(row=0, column=2, padx=10, pady=10)

# 自动划分数据集
Label(frame, text="数据集文件夹:").grid(row=1, column=0, padx=10, pady=10)
data_dir_label = Label(frame, text="未选择", fg="red")
data_dir_label.grid(row=1, column=1, padx=10, pady=10)
data_dir_button = Button(frame, text="选择文件夹", command=select_data_dir)
data_dir_button.grid(row=1, column=2, padx=10, pady=10)

# 手动上传数据集
Label(frame, text="训练集文件夹:").grid(row=2, column=0, padx=10, pady=10)
train_dir_label = Label(frame, text="未选择", fg="red")
train_dir_label.grid(row=2, column=1, padx=10, pady=10)
train_dir_button = Button(frame, text="选择文件夹", command=select_train_dir, state="disabled")
train_dir_button.grid(row=2, column=2, padx=10, pady=10)

Label(frame, text="验证集文件夹:").grid(row=3, column=0, padx=10, pady=10)
val_dir_label = Label(frame, text="未选择", fg="red")
val_dir_label.grid(row=3, column=1, padx=10, pady=10)
val_dir_button = Button(frame, text="选择文件夹", command=select_val_dir, state="disabled")
val_dir_button.grid(row=3, column=2, padx=10, pady=10)

continue_training_var = BooleanVar()
Checkbutton(frame, text="继续训练已有模型", variable=continue_training_var).grid(row=4, column=0, padx=10, pady=10)
continue_model_label = Label(frame, text="未选择", fg="red")
continue_model_label.grid(row=4, column=1, padx=10, pady=10)
continue_model_button = Button(frame, text="选择模型文件", command=select_model_to_continue)
continue_model_button.grid(row=4, column=2, padx=10, pady=10)

# NEW: Dataset Encoding Type
Label(frame, text="文本文件编码类型:").grid(row=5, column=0, padx=10, pady=10)
dataset_encoding_entry = Entry(frame)
dataset_encoding_entry.insert(0, DEFAULT_DATASET_ENCODING)
dataset_encoding_entry.grid(row=5, column=1, padx=10, pady=10)
Label(frame, text="例如: utf-8, gbk, latin-1").grid(row=5, column=2, padx=5, pady=0, sticky="W")


# 文本分类特有参数
Label(frame, text="批量大小:").grid(row=6, column=0, padx=10, pady=10)
batch_size_entry = Entry(frame)
batch_size_entry.insert(0, str(DEFAULT_BATCH_SIZE))
batch_size_entry.grid(row=6, column=1, padx=10, pady=10)

Label(frame, text="词汇表大小 (max_tokens):").grid(row=7, column=0, padx=10, pady=10)
max_tokens_entry = Entry(frame)
max_tokens_entry.insert(0, str(DEFAULT_MAX_TOKENS))
max_tokens_entry.grid(row=7, column=1, padx=10, pady=10)

Label(frame, text="序列最大长度 (sequence_length):").grid(row=8, column=0, padx=10, pady=10)
sequence_length_entry = Entry(frame)
sequence_length_entry.insert(0, str(DEFAULT_SEQUENCE_LENGTH))
sequence_length_entry.grid(row=8, column=1, padx=10, pady=10)

# 验证集比例滑动条
Label(frame, text="验证集比例 (%):").grid(row=9, column=0, padx=10, pady=10)
validation_split_scale = Scale(frame, from_=1, to=99, orient="horizontal")
validation_split_scale.set(20)
validation_split_scale.grid(row=9, column=1, padx=10, pady=10)

Label(frame, text="学习率:").grid(row=10, column=0, padx=10, pady=10)
learning_rate_entry = Entry(frame)
learning_rate_entry.insert(0, "0.001")
learning_rate_entry.grid(row=10, column=1, padx=10, pady=10)

Label(frame, text="训练轮数:").grid(row=11, column=0, padx=10, pady=10)
epochs_entry = Entry(frame)
epochs_entry.insert(0, "10")
epochs_entry.grid(row=11, column=1, padx=10, pady=10)

# 训练状态显示
current_epoch_label = Label(frame, text="当前轮数: 0")
current_epoch_label.grid(row=12, column=0, padx=10, pady=10)
train_loss_label = Label(frame, text="训练损失: 0.0000")
train_loss_label.grid(row=12, column=1, padx=10, pady=10)
train_acc_label = Label(frame, text="训练准确率: 0.0000")
train_acc_label.grid(row=12, column=2, padx=10, pady=10)
val_loss_label = Label(frame, text="验证损失: 0.0000")
val_loss_label.grid(row=13, column=0, padx=10, pady=10)
val_acc_label = Label(frame, text="验证准确率: 0.0000")
val_acc_label.grid(row=13, column=1, padx=10, pady=10)

# 开始训练和停止训练按钮
start_button = Button(frame, text="开始训练", command=start_training)
start_button.grid(row=14, column=1, padx=10, pady=20)
stop_button = Button(frame, text="停止训练", command=stop_training_callback, state="disabled")
stop_button.grid(row=14, column=2, padx=10, pady=20)

# 初始调用以设置正确的UI状态
toggle_dataset_selection()

# 运行主循环
root.mainloop()