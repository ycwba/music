import streamlit as st
import pandas as pd
from datetime import datetime
import numpy as np
from recommender import get_similar_songs # 假设这个模块存在且功能不变
from lyrics_analyzer import clean_lyrics # 假设这个模块存在且功能不变
import requests
import sys
import os

# 添加项目根目录到Python路径，确保可以导入style_classifier模块
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import style_classifier

st.set_page_config(
    page_title="智能推荐",
    page_icon="🎵",
    layout="wide"
)

# 设置中文页面标题和侧边栏
st.markdown("""
<style>
    /* 主标题 */
    .stApp header h1 {
        font-family: 'Microsoft YaHei', sans-serif;
    }
    
    /* 侧边栏标题 */
    [data-testid="stSidebarNav"] {
        font-family: 'Microsoft YaHei', sans-serif;
    }
    
    /* 侧边栏导航项 */
    [data-testid="stSidebarNav"] li div p {
        font-family: 'Microsoft YaHei', sans-serif;
    }
    
    /* 页面内容 */
    .stApp {
        font-family: 'Microsoft YaHei', sans-serif;
    }
    
    /* 导航项图标 */
    [data-testid="stSidebarNav"] ul li:nth-child(1) div p::before {
        content: "🎵 ";
    }
    
    [data-testid="stSidebarNav"] ul li:nth-child(2) div p::before {
        content: "📊 ";
    }
    
    [data-testid="stSidebarNav"] ul li:nth-child(3) div p::before {
        content: "🎵 ";
    }
    
    [data-testid="stSidebarNav"] ul li:nth-child(4) div p::before {
        content: "💾 ";
    }
    
    /* 修复侧边栏标题显示 */
    .css-1d391kg {
        font-family: 'Microsoft YaHei', sans-serif !important;
    }
    
    /* 修复侧边栏导航项显示 */
    .css-1d391kg p {
        font-family: 'Microsoft YaHei', sans-serif !important;
    }
</style>
""", unsafe_allow_html=True)
st.title("🎵 智能推荐")

# 初始化session state
if 'song_db' not in st.session_state:
    st.session_state['song_db'] = []
if 'recommendation_history' not in st.session_state:
    st.session_state['recommendation_history'] = []
if 'cache_styles' not in st.session_state:
    st.session_state['cache_styles'] = {}

@st.cache_data # 使用Streamlit的缓存机制，避免重复计算
def get_song_style(song_id, lyric, artist):
    """
    获取歌曲风格。使用style_classifier模块的分类器。
    此函数会缓存结果，以避免对相同歌曲重复调用模型。
    
    参数:
        song_id: 歌曲ID，用于缓存键
        lyric: 歌词文本
        artist: 歌手名称，用于清理歌词
        
    返回:
        str: 歌曲的主要风格
    """
    try:
        # 清理歌词文本
        cleaned_lyric = clean_lyrics(lyric, artist)
        
        # 如果清理后的歌词为空，返回默认值
        if not cleaned_lyric or cleaned_lyric.isspace():
            st.warning(f"歌曲 '{song_id}' 的歌词清理后为空，无法分析风格")
            return "未知"
        
        # 调用style_classifier模块中的分类函数
        # classify_lyrics_style返回(主风格, 置信度字典)
        try:
            main_style, confidence_scores = style_classifier.classify_lyrics_style(cleaned_lyric)
            
            # 在开发模式下可以启用调试信息
            # st.write(f"调试信息 - 歌曲ID: {song_id}")
            # st.write(f"主风格: {main_style}")
            # st.write(f"置信度: {confidence_scores}")
            
            # 确保main_style是字符串类型
            if isinstance(main_style, (list, np.ndarray)):
                main_style = str(main_style[0])  # 如果是数组，取第一个元素
            elif not isinstance(main_style, str):
                main_style = str(main_style)  # 转换为字符串
                
            return main_style
        except Exception as e:
            st.error(f"风格分类错误: {str(e)}")
            st.write("模型输出详情:")
            st.write(f"cleaned_lyric: {cleaned_lyric[:100]}...")  # 只显示前100个字符
            return "分析失败"
    except Exception as e:
        # 捕获所有异常，确保应用不会崩溃
        st.error(f"风格分析出错: {str(e)}")
        return "分析失败"

def add_to_history(base_song, recommended_songs, mode="song_based", filters=None):
    """添加推荐记录到历史"""
    history_entry = {
        'timestamp': datetime.now(),
        'mode': mode,
        'recommended_songs': recommended_songs
    }

    if mode == "song_based":
        history_entry['base_song'] = base_song
    else:  # multi_filter
        history_entry['filters'] = filters

    st.session_state['recommendation_history'].append(history_entry)
    # 只保留最近20条记录
    if len(st.session_state['recommendation_history']) > 20:
        st.session_state['recommendation_history'] = st.session_state['recommendation_history'][-20:]

# 检查是否有数据
if not st.session_state['song_db']:
    st.info("暂无歌词数据。请在'数据导入导出'页面添加歌词。")
else:
    # 确保所有歌曲的风格都被计算并缓存
    # 第一次加载或数据更新时运行
    for song in st.session_state['song_db']:
        # get_song_style 已经加了 @st.cache_data，所以这里调用会利用缓存
        # 传入 song_id, lyric, artist 作为缓存键
        style = get_song_style(song['id'], song['lyric'], song['artist'])
        if song['id'] not in st.session_state['cache_styles']:
            st.session_state['cache_styles'][song['id']] = style

    # 创建两列布局，指定比例为 6:4
    col1, col2 = st.columns([6, 4])

    with col1:
        st.subheader("推荐设置")

        # 获取所有歌手列表
        all_artists = list(set(song['artist'] for song in st.session_state['song_db']))
        # 从缓存中获取所有已计算的风格
        all_styles = list(set(st.session_state['cache_styles'].values()))

        # 推荐方式选择
        recommendation_mode = st.radio(
            "推荐方式",
            ["基于歌曲", "多重筛选"],
            horizontal=True
        )

        if recommendation_mode == "基于歌曲":
            # 选择基准歌曲
            song_options = [f"{song['title']} - {song['artist']}" for song in st.session_state['song_db']]
            selected_song = st.selectbox("选择歌曲", song_options)

            if selected_song:
                song_idx = song_options.index(selected_song)
                base_song = st.session_state['song_db'][song_idx]

                # 显示基准歌曲信息
                st.write("基准歌曲信息：")
                st.write(f"- 歌手：{base_song['artist']}")
                # 从缓存中获取风格
                st.write(f"- 风格：{st.session_state['cache_styles'].get(base_song['id'], '未知')}")

                # 推荐参数设置
                num_recommendations = st.slider("推荐数量", 1, 10, 5)
                consider_style = st.checkbox("考虑歌曲风格", value=True)

                if st.button("获取推荐"):
                    # 获取推荐结果
                    recommended = get_similar_songs(
                        base_song,
                        st.session_state['song_db'],
                        n_recommendations=num_recommendations,
                        consider_style=consider_style
                    )

                    # 添加到历史记录
                    add_to_history(base_song, recommended, mode="song_based")

                    # 显示推荐结果
                    st.write("### 🎵 推荐结果")
                    
                    # 显示基准歌曲的风格
                    try:
                        base_style = st.session_state['cache_styles'].get(base_song['id'], '未知')
                        if isinstance(base_style, (list, np.ndarray)):
                            base_style = str(base_style[0])
                        elif not isinstance(base_style, str):
                            base_style = str(base_style)
                        
                        st.write(f"基准歌曲风格: **{base_style}**")
                        
                        # 添加风格说明
                        with st.expander("查看风格说明"):
                            st.write("""
                            - 风格分析基于歌词内容进行
                            - 如果显示"未知"，可能是因为歌词内容不足
                            - 如果显示"分析失败"，可能是模型处理出现问题
                            """)
                    except Exception as e:
                        st.error(f"处理基准歌曲风格时出错: {str(e)}")
                        base_style = "未知"
                        
                    # 创建进度条
                    progress_bar = st.progress(0)
                    
                    for i, rec in enumerate(recommended, 1):
                        # 更新进度条
                        progress_bar.progress(i / len(recommended))
                        
                        # 获取推荐歌曲的风格
                        rec_style = st.session_state['cache_styles'].get(rec['id'], '未知')
                        encoded_title = requests.utils.quote(rec['title'])
                        
                        # 使用不同的emoji标记不同的风格匹配情况
                        style_match = "🎯" if rec_style == base_style else "🎵"
                        
                        # 创建一个容器来组织每个推荐项
                        with st.container():
                            st.markdown(f"""
                            {style_match} **{i}. [{rec['title']}](https://www.last.fm/search?q={encoded_title})** - {rec['artist']}
                            - 风格：**{rec_style}**
                            """)
                            
                            # 添加歌词查看选项
                            with st.expander("查看歌词"):
                                st.text(rec['lyric'])
                    
                    # 完成后清除进度条
                    progress_bar.empty()

        else:  # 多重筛选模式
            col1_inner, col2_inner = st.columns(2)

            with col1_inner:
                # 歌手多选
                selected_artists = st.multiselect(
                    "选择歌手(可多选)",
                    all_artists,
                    default=None
                )

            with col2_inner:
                # 风格多选
                selected_styles = st.multiselect(
                    "选择风格(可多选)",
                    all_styles,
                    default=None
                )

            # 推荐参数
            num_recommendations = st.slider("推荐数量", 1, 10, 5)

            if st.button("获取推荐"):
                # 筛选歌曲
                filtered_songs = st.session_state['song_db']

                # 应用歌手筛选
                if selected_artists:
                    filtered_songs = [
                        song for song in filtered_songs
                        if song['artist'] in selected_artists
                    ]

                # 应用风格筛选
                if selected_styles:
                    filtered_songs = [
                        song for song in filtered_songs
                        # 从缓存中获取风格进行筛选
                        if st.session_state['cache_styles'].get(song['id'], '未知') in selected_styles
                    ]

                # 检查筛选结果
                if not filtered_songs:
                    st.warning("没有找到符合条件的歌曲，请调整筛选条件")
                else:
                    # 显示筛选统计
                    st.write(f"### 找到 {len(filtered_songs)} 首符合条件的歌曲")

                    # 如果筛选结果太多，随机选取部分展示
                    display_count = min(10, len(filtered_songs))

                    # 确保 list(filtered_songs) 不为空，且 size 不大于 filtered_songs 的长度
                    if filtered_songs:
                        display_songs = np.random.choice(
                            list(filtered_songs), # 转换为列表，确保可以被 np.random.choice 接受
                            size=min(display_count, len(filtered_songs)), # 确保 size 不超过列表长度
                            replace=False
                        ).tolist()
                    else:
                        display_songs = []

                    # 显示部分结果预览
                    with st.expander("预览部分歌曲"):
                        for song in display_songs:
                            # 从缓存中获取风格
                            st.write(f"- **{song['title']}** - {song['artist']} ({st.session_state['cache_styles'].get(song['id'], '未知')})")

                    # 如果用户要求的推荐数量比实际歌曲少，调整数量
                    actual_recommendations = min(num_recommendations, len(filtered_songs))

                    # 随机推荐
                    if filtered_songs:
                        recommended = np.random.choice(
                            list(filtered_songs), # 转换为列表
                            size=actual_recommendations,
                            replace=False
                        ).tolist()
                    else:
                        recommended = []

                    # 准备筛选条件信息用于历史记录
                    filters = {
                        'artists': selected_artists if selected_artists else [],
                        'styles': selected_styles if selected_styles else []
                    }

                    # 添加到历史记录
                    add_to_history(None, recommended, mode="multi_filter", filters=filters)

                    # 显示推荐结果
                    st.write(f"### 🎵 为您推荐 {actual_recommendations} 首歌曲")
                    
                    # 如果有选择风格，显示风格匹配统计
                    if selected_styles:
                        st.write("### 风格匹配情况")
                        try:
                            style_counts = {}
                            for rec in recommended:
                                style = st.session_state['cache_styles'].get(rec['id'], '未知')
                                
                                # 处理非字符串类型的风格
                                if isinstance(style, (list, np.ndarray)):
                                    style = str(style[0])
                                elif not isinstance(style, str):
                                    style = str(style)
                                
                                style_counts[style] = style_counts.get(style, 0) + 1
                            
                            # 计算匹配的风格数量
                            matched_count = sum(1 for rec in recommended 
                                             if st.session_state['cache_styles'].get(rec['id'], '未知') in selected_styles)
                            
                            # 显示匹配摘要
                            st.success(f"✨ 在推荐结果中，有 {matched_count} 首歌曲与您选择的风格相匹配")
                            
                            # 使用列布局显示详细统计
                            st.write("#### 风格分布详情")
                            cols = st.columns(min(3, len(style_counts)))
                            for i, (style, count) in enumerate(style_counts.items()):
                                with cols[i % len(cols)]:
                                    is_selected = style in selected_styles
                                    delta_color = "normal" if is_selected else "off"
                                    st.metric(
                                        label=f"{'🎯 ' if is_selected else ''}{style}",
                                        value=f"{count} 首",
                                        delta=f"{count/len(recommended)*100:.1f}%",
                                        delta_color=delta_color
                                    )
                            
                            # 添加解释说明
                            with st.expander("💡 关于风格分析"):
                                st.info("""
                                - 风格分析基于歌词内容进行，可能会随歌词丰富程度变化
                                - 🎯 表示与您选择的风格匹配
                                - 百分比显示了每种风格在推荐结果中的占比
                                - 如果某首歌显示为"未知"，可能是因为歌词内容不足以进行分析
                                """)
                            
                        except Exception as e:
                            st.error(f"统计风格分布时出错: {str(e)}")
                    
                    # 创建进度条
                    progress_bar = st.progress(0)
                    
                    # 显示推荐列表
                    for i, rec in enumerate(recommended, 1):
                        # 更新进度条
                        progress_bar.progress(i / len(recommended))
                        
                        try:
                            # 获取推荐歌曲的风格并进行类型处理
                            rec_style = st.session_state['cache_styles'].get(rec['id'], '未知')
                            if isinstance(rec_style, (list, np.ndarray)):
                                rec_style = str(rec_style[0])
                            elif not isinstance(rec_style, str):
                                rec_style = str(rec_style)
                            
                            encoded_title = requests.utils.quote(rec['title'])
                            
                            # 选择合适的emoji和样式
                            if rec_style == "分析失败":
                                style_emoji = "⚠️"
                                style_color = "red"
                            elif rec_style == "未知":
                                style_emoji = "❓"
                                style_color = "gray"
                            elif selected_styles and rec_style in selected_styles:
                                style_emoji = "🎯"
                                style_color = "green"
                            else:
                                style_emoji = "🎵"
                                style_color = "blue"
                            
                            # 创建一个容器来组织每个推荐项
                            with st.container():
                                # 使用列布局来更好地组织信息
                                rec_col1, rec_col2 = st.columns([7, 3])
                                
                                with rec_col1:
                                    # 使用HTML来添加颜色
                                    st.markdown(f"""
                                    {style_emoji} **{i}. [{rec['title']}](https://www.last.fm/search?q={encoded_title})** - {rec['artist']}
                                    """, unsafe_allow_html=True)
                                
                                with rec_col2:
                                    # 显示风格信息
                                    style_match = ""
                                    if selected_styles and rec_style in selected_styles:
                                        style_match = " ✓"
                                    
                                    st.markdown(f"""
                                    <span style='color: {style_color}'><b>{rec_style}{style_match}</b></span>
                                    """, unsafe_allow_html=True)
                                
                                # 添加一个分隔线
                                if i < len(recommended) - 1:
                                    st.markdown("---")
                        except Exception as e:
                            st.error(f"显示推荐项 {i} 时出错: {str(e)}")
                            
                            # 添加歌词查看选项
                            with st.expander("查看歌词"):
                                st.text(rec['lyric'])
                    
                    # 完成后清除进度条
                    progress_bar.empty()
                    
                    # 添加提示信息
                    if selected_styles or selected_artists:
                        st.info("""
                        💡 图标说明：
                        - 🎯 完全匹配您选择的风格
                        - 🎵 其他推荐歌曲
                        """)

    with col2:
        st.subheader("推荐历史")

        if st.session_state['recommendation_history']:
            for history in reversed(st.session_state['recommendation_history']):
                # 根据推荐模式生成不同的标题
                if history['mode'] == "song_based":
                    title = f"基于《{history['base_song']['title']}》的推荐"
                else:  # multi_filter
                    filter_parts = []
                    if history['filters']['artists']:
                        filter_parts.append(f"歌手: {', '.join(history['filters']['artists'])}")
                    if history['filters']['styles']:
                        filter_parts.append(f"风格: {', '.join(history['filters']['styles'])}")
                    filter_desc = " | ".join(filter_parts) if filter_parts else "全部歌曲"
                    title = f"多重筛选推荐 ({filter_desc})"

                with st.expander(
                        f"{title} - {history['timestamp'].strftime('%Y-%m-%d %H:%M')}"
                ):
                    # 显示推荐条件
                    if history['mode'] == "song_based":
                        st.write("**基准歌曲：**")
                        base_song = history['base_song']
                        encoded_title = requests.utils.quote(base_song['title'])
                        st.write(f"- **[{base_song['title']}]("
                                 f"https://www.last.fm/search?q={encoded_title})** - "
                                 f"{base_song['artist']}")
                    else:
                        st.write("**筛选条件：**")
                        if history['filters']['artists']:
                            st.write(f"- 歌手: {', '.join(history['filters']['artists'])}")
                        if history['filters']['styles']:
                            st.write(f"- 风格: {', '.join(history['filters']['styles'])}")
                        if not history['filters']['artists'] and not history['filters']['styles']:
                            st.write("- 无特定筛选条件（全部歌曲）")

                    st.write("**推荐歌曲：**")
                    for i, rec in enumerate(history['recommended_songs'], 1):
                        encoded_title = requests.utils.quote(rec['title'])
                        st.write(f"{i}. **[{rec['title']}](https://www.last.fm/search?q={encoded_title})** - {rec['artist']}")
        else:
            st.info("暂无推荐历史记录")