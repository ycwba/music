import json
import tensorflow as tf
from tensorflow.keras.layers import TextVectorization
import numpy as np
import os
import pathlib
import sys

# 配置 GPU
gpus = tf.config.list_physical_devices("GPU")
if gpus:
    try:
        # tf.config.experimental.set_memory_growth 是一个老旧的API，但为了兼容性保留
        for gpu in gpus:
            tf.config.experimental.set_memory_growth(gpu, True)
        tf.config.set_visible_devices(gpus, "GPU")
        print("GPU 配置成功，内存增长已开启。")
    except RuntimeError as e:
        print(f"GPU配置失败，可能需要在程序启动时设置: {e}")
else:
    print("未检测到GPU，将使用CPU进行训练。")

# --- 默认模型和元数据文件路径（请根据你的实际情况修改） ---
_DEFAULT_MODEL_BASE_DIR = "models"
_DEFAULT_MODEL_FILENAME = "text_model.keras"
_DEFAULT_METADATA_FILENAME = "metadata.json"

# --- 假定训练时使用的 TextVectorization 参数 (如果模型中未保存这些信息) ---
# 这些参数必须与训练文本分类模型时使用的参数一致
_DEFAULT_SEQUENCE_LENGTH = 256
# max_tokens 将从加载的 vocabulary 长度推断

# --- 模型和向量化层以及类别名称的全局引用，只加载一次 ---
_loaded_model = None
_loaded_vectorizer = None
_loaded_class_names = None
_model_loaded_successfully = False

def _load_model_and_metadata_once(model_base_dir=_DEFAULT_MODEL_BASE_DIR, 
                                 model_filename=_DEFAULT_MODEL_FILENAME, 
                                 metadata_filename=_DEFAULT_METADATA_FILENAME):
    """
    内部函数：尝试只加载一次模型和元数据。
    """
    global _loaded_model, _loaded_vectorizer, _loaded_class_names, _model_loaded_successfully

    if _model_loaded_successfully:
        return

    model_path = os.path.join(model_base_dir, model_filename)
    metadata_path = os.path.join(model_base_dir, metadata_filename)

    if not os.path.exists(model_path):
        print(f"错误: 模型文件未找到: {model_path}. 请检查路径。", file=sys.stderr)
        return
    if not os.path.exists(metadata_path):
        print(f"错误: 元数据文件未找到: {metadata_path}. 请检查路径。", file=sys.stderr)
        return

    # 加载模型
    try:
        model = tf.keras.models.load_model(model_path)
        print(f"成功加载模型: {model_path}")
    except Exception as e:
        print(f"错误: 加载模型失败: {e}", file=sys.stderr)
        return

    # 加载元数据
    try:
        with open(metadata_path, 'r', encoding='utf-8') as f:
            metadata = json.load(f)
        print(f"成功加载元数据: {metadata_path}")
    except json.JSONDecodeError as e:
        print(f"错误: 加载元数据文件失败 (JSON 格式错误): {e}", file=sys.stderr)
        return
    except Exception as e:
        print(f"错误: 读取元数据文件时发生未知错误: {e}", file=sys.stderr)
        return

    # 获取词汇表和类别名称
    vocabulary = metadata.get("vocabulary")
    class_names = metadata.get("class_names")

    if not vocabulary:
        print("错误: 元数据文件中未找到 'vocabulary' 键。", file=sys.stderr)
        return
    if not class_names:
        print("错误: 元数据文件中未找到 'class_names' 键。", file=sys.stderr)
        return
    
    # 重新创建 TextVectorization 层并设置词汇表
    # max_tokens 应基于实际加载的词汇表大小
    vectorization_layer = TextVectorization(
        max_tokens=len(vocabulary), # The size of the actual vocabulary
        output_mode='int',
        output_sequence_length=_DEFAULT_SEQUENCE_LENGTH,
        standardize="lower_and_strip_punctuation" # 必须与训练时一致
    )
    vectorization_layer.set_vocabulary(vocabulary)
    print(f"TextVectorization层已设置词汇表，大小为 {len(vocabulary)}。")

    _loaded_model = model
    _loaded_vectorizer = vectorization_layer
    _loaded_class_names = class_names
    _model_loaded_successfully = True
    print(f"模型和向量化层加载完成，包含 {len(class_names)} 个类别: {class_names}")

def classify_lyrics_style(lyrics: str) -> tuple[str, dict[str, float]]:
    """
    使用预训练的文本分类模型对歌词进行风格分类。
    
    :param lyrics: 待分类的歌词字符串。
    :return: 包含 (主风格: str, 置信度字典: dict[str, float]) 的元组。
             如果模型未加载成功，将返回 ('Unknown', {}) 或抛出 RuntimeError。
    :raises ValueError: 如果歌词不是非空字符串。
    :raises RuntimeError: 如果模型未能成功加载。
    """
    if not isinstance(lyrics, str) or not lyrics.strip():
        raise ValueError("歌词必须是非空的字符串。")
    
    # 确保模型只被加载一次
    _load_model_and_metadata_once()

    if not _model_loaded_successfully:
        raise RuntimeError("文本分类模型未成功加载，无法进行风格分类。请检查路径和文件。")

    # 数据预处理
    # TextVectorization 期望输入是一个批次的文本，即使只有一个样本
    # tf.constant([lyrics]) 将单个字符串转换为 (1,) 形状的张量
    processed_lyrics = _loaded_vectorizer(tf.constant([lyrics]))

    # 进行预测
    # .predict() 返回一个 numpy 数组
    predictions = _loaded_model.predict(processed_lyrics, verbose=0) # verbose=0 关闭预测时的进度条
    
    # predictions 的形状会是 (1, num_classes)，我们取第一个样本的预测概率
    probabilities = predictions[0]  # 获取第一个样本的预测结果

    try:
        # 将概率与类别名称关联，确保转换为Python标量
        confidence_scores = {
            class_name: float(prob) 
            for class_name, prob in zip(_loaded_class_names, probabilities)
        }

        # 找出得分最高的风格作为主风格
        if not confidence_scores:
            return "Unknown", {}  # Should not happen if class_names exist
        
        main_style = max(confidence_scores.items(), key=lambda x: x[1])[0]
        
        # 确保返回的是字符串类型
        return str(main_style), confidence_scores
    except Exception as e:
        print(f"处理预测结果时出错: {e}", file=sys.stderr)
        return "Unknown", {}
    
    return main_style, confidence_scores

# --- 示例用法 ---
if __name__ == "__main__":
    print("--- 启动歌词风格分类库的独立测试模式 ---")
    print(f"尝试从 '{_DEFAULT_MODEL_BASE_DIR}' 文件夹加载模型...")

    # 可以在这里显式调用加载函数，或者依赖 classify_lyrics_style 第一次调用时自动加载
    # _load_model_and_metadata_once() 

    # 示例歌词
    sample_lyrics_1 = "阳光明媚，微风轻抚，心情像花儿一样绽放，充满了希望和爱。这首歌充满了积极能量。"
    sample_lyrics_2 = "夜深人静，思绪万千，回忆如潮水般涌来，孤独在心头蔓延，让人感到悲伤惆怅。"
    sample_lyrics_3 = "节奏强烈，舞动身躯，释放所有能量，感受这电音的魅力，重复的鼓点让人无法停止。"
    sample_lyrics_4 = "古老的钟声敲响，历史的尘埃飘散，江湖恩怨情仇，一剑一酒入画。"
    sample_lyrics_5 = "嘻哈说唱，街头文化，我的flow在空中爆炸，不屑世俗的眼光，做最真实的自己。"

    test_lyrics = {
        "乐观": sample_lyrics_1,
        "悲伤": sample_lyrics_2,
        "电子": sample_lyrics_3,
        "古风": sample_lyrics_4,
        "说唱": sample_lyrics_5,
    }

    print("\n--- 开始分类测试 ---")
    for sentiment, lyrics in test_lyrics.items():
        try:
            print(f"\n歌词示例 ({sentiment}风格): \"{lyrics[:40]}...\"")
            main_style, scores = classify_lyrics_style(lyrics)
            print(f"  预测主风格: {main_style}")
            print("  所有风格置信度:")
            # 按照置信度从高到低排序并打印
            for style, score in sorted(scores.items(), key=lambda item: item, reverse=True):
                print(f"    - {style}: {score:.4f} ({score:.2%})")
            print("--------------------------------------------------")
        except Exception as e:
            print(f"  分类时发生错误: {e}", file=sys.stderr)
            print("--------------------------------------------------")

    print("\n--- 结束独立测试模式 ---")