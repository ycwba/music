import os
import sys
import time
import socket
import threading
import subprocess
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import webbrowser

class SimpleLauncher:
    def __init__(self, root):
        self.root = root
        self.root.title("Streamlit启动器")
        self.root.geometry("500x300")
        
        self.setup_ui()
        self.process = None
        self.is_running = False
    
    def setup_ui(self):
        """设置UI界面"""
        # 端口设置
        port_frame = ttk.Frame(self.root, padding="10")
        port_frame.pack(fill=tk.X)
        
        ttk.Label(port_frame, text="端口:").pack(side=tk.LEFT)
        self.port_var = tk.StringVar(value="8501")
        ttk.Entry(port_frame, textvariable=self.port_var, width=8).pack(side=tk.LEFT, padx=5)
        
        # 控制按钮
        btn_frame = ttk.Frame(self.root, padding="10")
        btn_frame.pack(fill=tk.X)
        
        self.start_btn = ttk.Button(btn_frame, text="启动", command=self.start_app)
        self.start_btn.pack(side=tk.LEFT, padx=5)
        
        self.stop_btn = ttk.Button(btn_frame, text="停止", command=self.stop_app, state=tk.DISABLED)
        self.stop_btn.pack(side=tk.LEFT, padx=5)
        
        self.browser_btn = ttk.Button(btn_frame, text="打开浏览器", command=self.open_browser, state=tk.DISABLED)
        self.browser_btn.pack(side=tk.LEFT, padx=5)
        
        # 状态显示
        status_frame = ttk.Frame(self.root, padding="10")
        status_frame.pack(fill=tk.X)
        
        ttk.Label(status_frame, text="状态:").pack(side=tk.LEFT)
        self.status_label = ttk.Label(status_frame, text="未运行", foreground="red")
        self.status_label.pack(side=tk.LEFT, padx=5)
        
        # 日志
        log_frame = ttk.LabelFrame(self.root, text="日志", padding="5")
        log_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.log_text = scrolledtext.ScrolledText(log_frame, height=8)
        self.log_text.pack(fill=tk.BOTH, expand=True)
    
    def log(self, message):
        """添加日志"""
        self.log_text.insert(tk.END, f"{message}\n")
        self.log_text.see(tk.END)
    
    def check_port(self, port):
        """检查端口是否可用"""
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(1)
                return s.connect_ex(('localhost', port)) != 0
        except:
            return True
    
    def start_app(self):
        """启动应用"""
        try:
            port = int(self.port_var.get())
            if not (1024 <= port <= 65535):
                messagebox.showerror("错误", "端口号必须在1024-65535之间")
                return
        except ValueError:
            messagebox.showerror("错误", "请输入有效的端口号")
            return
        
        if self.is_running:
            messagebox.showinfo("提示", "应用已在运行")
            return
        
        if not self.check_port(port):
            messagebox.showerror("错误", f"端口 {port} 已被占用")
            return
        
        # 查找main.py
        if getattr(sys, 'frozen', False):
            app_dir = os.path.dirname(sys.executable)
        else:
            app_dir = os.path.dirname(os.path.abspath(__file__))
        
        main_file = os.path.join(app_dir, 'main.py')
        if not os.path.exists(main_file):
            messagebox.showerror("错误", f"找不到main.py文件: {main_file}")
            return
        
        # 启动进程
        self.log("正在启动应用...")
        threading.Thread(target=self._start_process, args=(main_file, port), daemon=True).start()
    
    def _start_process(self, main_file, port):
        """在后台启动进程"""
        try:
            cmd = [
                sys.executable, "-m", "streamlit", "run", main_file,
                "--server.port", str(port),
                "--server.headless", "true"
            ]
            
            # Windows下隐藏控制台窗口
            kwargs = {}
            if sys.platform.startswith('win'):
                kwargs['creationflags'] = subprocess.CREATE_NO_WINDOW
            
            self.process = subprocess.Popen(cmd, **kwargs)
            
            # 等待启动
            for i in range(15):
                if not self.check_port(port):
                    self.root.after(0, self._start_success)
                    return
                time.sleep(1)
            
            self.root.after(0, self._start_failed)
            
        except Exception as e:
            self.log(f"启动失败: {e}")
            self.root.after(0, self._start_failed)
    
    def _start_success(self):
        """启动成功"""
        self.is_running = True
        self.status_label.config(text="运行中", foreground="green")
        self.start_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self.browser_btn.config(state=tk.NORMAL)
        self.log("应用启动成功")
    
    def _start_failed(self):
        """启动失败"""
        self.status_label.config(text="启动失败", foreground="red")
        self.log("应用启动失败")
        if self.process:
            self.process.terminate()
            self.process = None
    
    def stop_app(self):
        """停止应用"""
        if not self.is_running:
            return
        
        self.log("正在停止应用...")
        
        if self.process:
            self.process.terminate()
            try:
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.process.kill()
            self.process = None
        
        self.is_running = False
        self.status_label.config(text="未运行", foreground="red")
        self.start_btn.config(state=tk.NORMAL)
        self.stop_btn.config(state=tk.DISABLED)
        self.browser_btn.config(state=tk.DISABLED)
        self.log("应用已停止")
    
    def open_browser(self):
        """打开浏览器"""
        if self.is_running:
            url = f"http://localhost:{self.port_var.get()}"
            webbrowser.open(url)
        else:
            messagebox.showinfo("提示", "应用未运行")

def main():
    root = tk.Tk()
    app = SimpleLauncher(root)
    
    # 退出时清理
    def on_closing():
        # 如果应用正在运行，显示确认对话框
        if app.is_running:
            result = messagebox.askyesno(
                "确认退出", 
                "应用正在运行中，是否先停止应用并退出？\n\n"
                "选择'是'：停止应用并退出\n"
                "选择'否'：取消退出，返回程序"
            )
            
            if not result:  # 否 - 取消退出
                return
            else:  # 是 - 先停止应用再退出
                app.log("正在自动停止应用...")
                app.stop_app()
                # 给一点时间让停止操作完成
                root.after(500, lambda: _final_exit())
                return
        else:
            # 应用未运行，直接确认退出
            if not messagebox.askyesno("确认退出", "确定要退出程序吗？"):
                return
        
        _final_exit()
    
    def _final_exit():
        """最终退出程序"""
        root.destroy()
    
    root.protocol("WM_DELETE_WINDOW", on_closing)
    root.mainloop()

if __name__ == "__main__":
    main()